import React from "react";
import { FaCircleArrowUp, FaCircleArrowDown } from "react-icons/fa6";

import { calcPercentChange } from "../utils/metrics";

export function ActivitiesTrackHead({ summary }) {
  const todayMinutes = summary?.todayMinutes;
  const yesterdayMinutes = summary?.yesterdayMinutes;

  const diff = calcPercentChange(todayMinutes, yesterdayMinutes);

  return (
    <>
      <div className="activities-head">
        <span>
          <h1>{todayMinutes} Menit</h1>
          <span
            className={` ${
              diff.isUp ? "trend-up" : diff.isDown ? "trend-down" : ""
            }`}
          >
            {diff >= 0 ? <FaCircleArrowDown /> : <FaCircleArrowDown />}
            {diff.percentText}
          </span>
        </span>
        <p>Perbandingan dengan hari sebelumnya</p>
      </div>
    </>
  );
}
